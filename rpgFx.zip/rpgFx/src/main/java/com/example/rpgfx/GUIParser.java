package com.example.rpgfx;

public class GUIParser implements InputParser{


    @Override
    public void welcome() {

    }

    @Override
    public void nbrHero() {

    }

    @Override
    public void whichHero(int x) {

    }

    @Override
    public void nameHero(int nbr) {

    }

    @Override
    public void nameTeam() {

    }

    @Override
    public void showTeam(Team team) {

    }

    @Override
    public void annonceTour() {

    }

    @Override
    public void choixAction() {

    }

    @Override
    public void choixCible() {

    }

    @Override
    public void choixObjet() {

    }


}
