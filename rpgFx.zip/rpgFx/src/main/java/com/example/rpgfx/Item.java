package com.example.rpgfx;

public class Item {

    protected String nom;

    public String getName() {
        return nom;
    }




}
