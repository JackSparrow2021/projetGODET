package com.example.rpgfx;

public class Healer extends SpellCaster {



    public Healer(String name, int health, int mana, int defense, Team team) {
        this.name = name;
        this.health = health;
        this.mana = mana;
        this.defense = defense;
        this.heroType = heroType.HEALER;
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Food("Sweat", 30));
        this.team = team;
        this.team.addCombatant(this);



    }


    @Override
    public void attack(Combatant cible) {
        Hero h = (Hero)cible;
        cible.updateHealth(30);
        if(cible.getHealth()>h.getMaxHealth()){
            cible.setHealth(h.getMaxHealth());
        }

        System.out.println("your hero "+ cible.getName() + " now has " + cible.getHealth() + "HealthPoint.");



    }

    @Override
    public void levelUp() {
        this.maxHealth+=10;
        this.health = this.maxHealth;
        this.maxMana += 20;
        this.mana = this.maxMana;


    }
}
