package com.example.rpgfx;

public abstract class Consumable extends Item{

    String name;
    int moreMana;
    int moreHealth;

    public abstract void use(Hero hero);


    public String getName() {return this.name;}
    }

