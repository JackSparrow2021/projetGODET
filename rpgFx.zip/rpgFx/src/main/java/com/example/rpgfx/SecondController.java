package com.example.rpgfx;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class SecondController{

    @FXML
    void chargeGame(MouseEvent event){
        Game game = new Game();
        System.out.println();
        game.start();
    }




}
