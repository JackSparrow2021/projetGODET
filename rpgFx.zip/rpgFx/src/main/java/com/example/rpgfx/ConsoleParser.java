package com.example.rpgfx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ConsoleParser implements InputParser {

    public Scanner scanner;
    private Game game;

    public ConsoleParser(Game game){
        this.game = game;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void welcome() {
        System.out.println("Welcome to my RPG game, stay calm, everything will go well...");
        System.out.println("\n-----------------------------");
        System.out.println("\nForm your team to fight the monsters of this island !");

        this.nbrHero();

    }

    @Override
    public void nbrHero() {
        System.out.println("How many Heroes do you wanna play ?");
        int nbr = askNbr(this.scanner);
        if (nbr >= 7) {
            System.out.println("Please enter a positive number under 8");
            nbr = askNbr(this.scanner);

        }

        this.game.setTotalHero(nbr);
        this.game.loopHero(1);


    }
    @Override
    public void nameTeam() {
        System.out.println("Please enter a name for your hero team :");
        String name = this.scanner.nextLine();
        this.game.createTeam(name);
    }

    @Override
    public void whichHero(int nombre) {

        System.out.println("You will now make a very important choice which is the selection of your heroes" +
                "\nplease choose the class of the hero number" + nombre);

        System.out.println("Warrior (1)");
        System.out.println("Mage (2)");
        System.out.println("Hunter (3)");
        System.out.println("Healer (4)");

        int number = askNbr(this.scanner);

        while (number != 1 && number != 2 && number != 3 && number != 4) {
            System.out.println("Please enter one of the following numbers : 1, 2, 3, 4");
            number = askNbr(this.scanner);
        }

        this.nameHero(number);
    }


    @Override
    public void nameHero(int nbr) {
        System.out.println("what name do you want to give your hero ?");
        String name = this.scanner.nextLine();
        this.game.createHero(nbr, name);


    }

    @Override
    public void showTeam(Team team) {
        if (team.getTeamList().size() > 0) {
            Combatant combatant0 = team.getTeamList().get(0);
            if (combatant0 instanceof Hero) {
                System.out.println("Here are your heroes");
                for (Combatant combatant : team.getTeamList()) {
                    Hero hero = (Hero) combatant;
                    System.out.println("Class : " + hero.getHeroType().toString() +
                            " | Name : " + hero.getName() + " | Health Point : " + hero.getHealth());

                }
                this.game.createEnemy(this.game.getTotalHero());


            } else {
                System.out.println("Here are your enemies :");
                for (Combatant c : team.getTeamList())
                    System.out.println("Name : " + c.getName() + " | Life points : " + c.getHealth() + " | Strength : " + c.getStrength() + " | Defense : " + c.getDefense() + " | Magical Defense : " + c.getMagicalDefense());
                this.game.ordre();
            }

        }

    }
    @Override
    public void annonceTour() {
        System.out.println("\nIt s the turn of "+this.game.getActualCombatant().getName());
        System.out.println("\n"+"-".repeat(30));
        this.choixAction();
    }

    @Override
    public void choixAction() {
        if (this.game.getActualCombatant() instanceof Hero) {
            System.out.println("What action do you want to perform ?");
            System.out.println("(1) Attack");
            System.out.println("(2) Object");
            int input = askNbr(this.scanner);
            while (input != 1 && input != 2) {
                System.out.println("please enter 1 or 2");
                input = askNbr(this.scanner);
            }
            if (input == 1) {
                this.choixCible();
            } else {
                this.choixObjet();
            }

        } else {
            int i = (int) (Math.random() * this.game.getTeamHero().listeVivant().size() - 1);
            Combatant cible = this.game.getTeamHero().listeVivant().get(i);
            this.game.executeAttack(cible);
        }
    }

    @Override
    public void choixCible() {
        System.out.println("\nPlease choose your target :");
        ArrayList<Combatant> List;
        if(this.game.getActualCombatant() instanceof Healer){
            List = this.game.getTeamHero().listeVivant();
        }
        else {
            List = this.game.getTeamEnemy().listeVivant();
        }
        for (Combatant combatant : List) {
            int indice = List.indexOf(combatant) + 1;
            System.out.println("(" + (indice ) + ") " + combatant.getName() + " | Life points : " + combatant.getHealth());
        }

        int input = askNbr(this.scanner);
        while (input < 1 || input >List.size() + 1) {
            System.out.println("Please enter a valid entry ");
            input = askNbr(this.scanner);
        }
        Combatant cible = List.get(input - 1);
        System.out.println("");
        this.game.executeAttack(cible);



    }


    @Override
    public void choixObjet() {
        Hero h = (Hero) this.game.getActualCombatant();
        if(h.getConsumables().size()>0){
            System.out.println("Please choose an object to consume : \n");
            for(Consumable c : h.getConsumables()){
                if(c instanceof Food){
                    System.out.println("("+(h.getConsumables().indexOf(c)+1)+") "+ c.getName());
                }else{
                    System.out.println("("+(h.getConsumables().indexOf(c)+1)+") "+c.getName());
                }

            }
            int intput = askNbr(this.scanner);
            while (intput<1 && intput>h.getConsumables().size()){
                System.out.println("Please enter a correct value");
                intput = askNbr(this.scanner);
            }
            System.out.println("The fighter used an object and now have " + h.getHealth() +" healthpoint and "+ h.getMana() + " of mana \n");
            this.game.useConsumable(intput);

        }else{
            System.out.println("You have no objects to consume");
            this.game.finTour();
        }

    }


    public static boolean numbers(String chiffre) {
        List<Character> accept = Arrays.asList('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
        char[] chiffreList = chiffre.toCharArray();
        for (char c : chiffreList) {
            if (!accept.contains(c)) {
                return false;
            }
        }
        return true;
    }

    public static int askNbr(Scanner scanner) {
        String chiffre = scanner.nextLine();
        while (!numbers(chiffre)) {
            System.out.println("please enter a number");
            chiffre = scanner.nextLine();
        }
        return Integer.parseInt(chiffre);

    }
}









