package com.example.rpgfx;

import java.util.ArrayList;

public abstract class Combatant {

    protected String name;
    protected int health;
    protected int mana;
    protected int strength;
    protected int power;
    protected int defense;
    protected int magicalDefense;
    protected boolean alive = true;

    protected Team team;



    public String getName(){return this.name;}

    public void setHealth(int health) {
        this.health = health;
    }
    public void setMana(int mana) {
        this.mana = mana;
    }


    public int getHealth(){return this.health;}

    public int getMana(){return this.mana;}

    public int getStrength(){return this.strength;}

    public int getDefense(){return this.defense;}

    public int getMagicalDefense(){return this.magicalDefense;}


    public void updateHealth(int x){this.health += x;}

    public void updateMana(int x){this.mana += x;}

    public void updateStrength(int x){this.strength += x;}
    public void updatePower(int x){this.power += x;}

    public void updateDefense(int x){this.defense += x;}

    public void updateMagicalDefense(int x){this.magicalDefense += x;}


    public void setVivant(boolean alive) {
        this.alive = alive;
    }

    public abstract void attack(Combatant cible);
    public abstract void levelUp();



}