package com.example.rpgfx;

public class Food extends Consumable{

    public Food(String name, int moreMana) {
        this.name = name;
        this.moreHealth = moreHealth;
    }

    @Override
    public void use(Hero hero) {

    }
    public String getName(){return this.name;}
}
