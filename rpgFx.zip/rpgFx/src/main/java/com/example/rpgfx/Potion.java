package com.example.rpgfx;


public class Potion extends Consumable {

    public Potion(String name, int moreMana) {
        this.name = name;
        this.moreMana = moreMana;
    }

    @Override
    public void use(Hero hero){
        hero.setMana(hero.getMana() + this.moreMana);
        if (hero.getMaxMana()<hero.getMana()){
            hero.setMana(hero.getMaxMana());
        }
        System.out.println("Le hero " + hero.getName() +" a utilisé la potion "+this.name+" et a restauré "+ this.moreMana+
                " de mana");
    }

}
