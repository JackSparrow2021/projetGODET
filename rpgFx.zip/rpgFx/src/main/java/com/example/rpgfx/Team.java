package com.example.rpgfx;

import java.util.ArrayList;

public class Team {

    private String teamName;

    public ArrayList<Combatant> teamList = new ArrayList<Combatant>();


    public int getSize() {
        return this.teamList.size();
    }

    public ArrayList<Combatant> getTeamList() {
        return teamList;
    }


    public void addCombatant(Combatant combatant) {
        this.teamList.add(combatant);
    }


    public Team(String teamName) {
        this.teamList = new ArrayList<Combatant>();
        this.teamName = teamName;
    }

    public ArrayList<Combatant> listeVivant() {
        ArrayList<Combatant> liste = new ArrayList<Combatant>();
        for (Combatant c : this.teamList) {
            if (c.alive) {
                liste.add(c);
            }
        }
        return liste;
    }
}
