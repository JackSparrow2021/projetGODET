package com.example.rpgfx;



public class Enemy extends Combatant {

    protected Team team;

    public Enemy(String name, int health, int strength, int defense, int magicalDefense, Team team) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.defense = defense;
        this.magicalDefense = magicalDefense;
        this.team = team;
        this.team.addCombatant(this);


    }

    public int getStrength() {return this.strength;}

    @Override
    public void attack(Combatant cible) {
        int damage = this.strength - cible.getDefense();
        if( damage < 0){
            damage = 0;
        }
        cible.updateHealth(-damage);
        System.out.println("\nYour hero "  + cible.getName() + " has been attacked, he has " + cible.getHealth() + " healthPoint." );
        if(cible.getHealth()<=0){
            cible.setVivant(false);
            System.out.println("\nYour hero " + cible.getName() + " died under the blows of demons.");
        }



    }

    @Override
    public void levelUp() {
        this.updateHealth(10);
        this.updateDefense(5);
        this.updateStrength(5);
        this.updateMagicalDefense(5);
    }

}