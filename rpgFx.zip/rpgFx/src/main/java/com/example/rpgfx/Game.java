package com.example.rpgfx;

import java.util.ArrayList;


public class Game {

    private InputParser inputParser;
    private Team teamHero;
    private Team teamEnemy;
    private int totalHero;
    private Combatant actualCombatant;
    private ArrayList<Combatant> ordreTour = new ArrayList<Combatant>();

    private int level = 1;


    public Game() {
        this.teamEnemy = new Team("monster team");
    }


    public void setInputParser(InputParser inputParser) {
        this.inputParser = inputParser;
    }

    public int getLevel() {
        return this.level;
    }


    public void start() {
        this.inputParser.nameTeam();

    }

    public void createTeam(String nameTeam) {
        this.teamHero = new Team(nameTeam);
        this.inputParser.welcome();
    }

    public void boucleHero(int actual) {
        if (actual <= this.totalHero) {
            this.inputParser.whichHero(actual);
        } else {
            this.inputParser.showTeam(teamHero);
        }
    }

    public void createHero(int nbr, String name) {

        if (nbr == 1) {
            new Warrior(name, 100, 50, 20, this.teamHero);
        } else if (nbr == 2) {
            new Mage(name, 100, 100, 50, 15, this.teamHero);
        } else if (nbr == 3) {
            new Hunter(name, 100, 100, 40, 15, 10, this.teamHero);
        } else if (nbr == 4) {
            new Healer(name, 100, 100, 15, this.teamHero);
        }
        this.boucleHero(this.teamHero.getTeamList().size() + 1);


    }

    public void createEnemy(int nombreHero) {

        int health = 90 + (level * 10);
        int strength = 20 + (level * 5);
        int defense = 10 + (level * 5);
        int magicalDefense = 15 + (level * 5);
        for (int i = 0; i < nombreHero; i += 1) {
            new Enemy("Gobelin", health, strength, defense, magicalDefense, this.teamEnemy);
        }
        this.inputParser.showTeam(this.teamEnemy);

    }

    public void bossFinal() {
        new Enemy("Titan", 300, 45, 45, 35, this.teamEnemy);
        this.inputParser.showTeam(this.teamEnemy);
    }

    public void setTotalHero(int totalHero) {
        this.totalHero = totalHero;
    }

    public int getTotalHero() {
        return totalHero;
    }

    public Combatant getActualCombatant() {
        return actualCombatant;
    }

    public Team getTeamEnemy() {
        return teamEnemy;
    }

    public void ordre() {
        for (int i = 0; i < this.totalHero; i = i + 1) {
            this.ordreTour.add(this.teamHero.getTeamList().get(i));
            this.ordreTour.add(this.teamEnemy.getTeamList().get(i));
        }
        this.nextCombatant();
        this.inputParser.annonceTour();
    }

    public void loopHero(int actuel) {
        if (actuel <= this.totalHero) {
            this.inputParser.whichHero(actuel);
        } else {
            this.inputParser.showTeam(teamHero);
        }
    }

    public Team getTeamHero() {
        return teamHero;
    }


    public void executeAttack(Combatant cible) {


        actualCombatant.attack(cible);
        this.finTour();

    }

    public void finTour() {
        if (this.teamHero.listeVivant().size() == 0) {
            this.lose();
        } else if (this.teamEnemy.listeVivant().size() == 0) {
            if (this.level <= 3) {
                this.levelUp();
                this.win();
            } else if (this.level == 4) {
                this.bossFinal();
            } else {
                this.win();
            }
        } else {
            this.nextCombatant();
            this.inputParser.annonceTour();
        }
    }

    public void lose() {
        System.out.println("you just lose the game");
    }

    public void win() {
        System.out.println("Congratulation ! you won the game!");
    }

    public void levelUp() {
        this.level++;
        System.out.println("well done, you go to the next level, the level " + this.getLevel() + " good luck !");

        for (Combatant c : this.teamHero.getTeamList()) {
            Hero h = (Hero) c;
            h.levelUp();
        }
        this.teamEnemy = new Team("Enemy team");
        this.createEnemy(this.totalHero);

    }

    public void nextCombatant() {
        int i = this.ordreTour.indexOf(this.actualCombatant);
        if (i + 1 == this.ordreTour.size()) {
            i = 0;
        } else {
            i = i + 1;
        }
        this.actualCombatant = this.ordreTour.get(i);
    }

    public void useConsumable(int input) {
        Hero h = (Hero) this.actualCombatant;
        h.useConsumable(h.getConsumables().get(input - 1));
        this.finTour();
    }

}


