package com.example.rpgfx;

public interface InputParser {
    void welcome();
    void nbrHero();
    void whichHero(int x);
    void nameHero(int nbr);
    void nameTeam();
    void showTeam(Team team);
    void annonceTour();
    void choixAction();
    void choixCible();
    void choixObjet();







}
