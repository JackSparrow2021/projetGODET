package com.example.rpgfx;

import java.util.Random;
import java.util.Scanner;

public class Mage extends SpellCaster {
    int power;

    public Mage(String name, int health, int mana,int power, int defense, Team team) {
        this.name = name;
        this.health = health;
        this.power = power;
        this.mana= mana;
        this.defense = defense;
        this.heroType = heroType.MAGE;
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Food("Sweat", 30));
        this.team = team;
        this.team.addCombatant(this);
    }

    public int getPower(){return this.power;}
    public int getStrength (){return this.strength;}


    public void FireBall(Combatant cible){
        if (this.getMana() < 10){
            System.out.println("You don't have enough Mana, Sorry.");
        }
        else {
            Random random = new Random();
            int R = random.nextInt(11);
            int DamageInflected = this.getPower() - cible.getMagicalDefense();
            if (R > 7) {
                System.out.println("Critical Strike !");
                DamageInflected *= 2;
            }


            cible.updateHealth(-DamageInflected);
            cible.updateStrength(-5);

            this.updateMana(-10);

            cible.getHealth();
            cible.getStrength();

            this.getMana();

            System.out.println("The target has " +cible.getHealth() + " Point of life, " + cible.getStrength() + "of Strength and the mage have " + this.getMana() +" mana left");
            if(cible.getHealth()<=0){
                cible.setVivant(false);
                System.out.println("\nThe target is dead! Another small effort.");

            }
        }


    }


    public void IceBall(Combatant cible){
        if (this.getMana() < 20){
            System.out.println("You don't have enough Mana, Sorry.");
        }
        else {
            Random random = new Random();
            int R = random.nextInt(11);
            double DamageInflected = this.getPower() * (1.3) - cible.getMagicalDefense();
            if (R > 7) {
                System.out.println("Critical Strike !");
                DamageInflected *= 2;
            }


            cible.updateHealth((int) -DamageInflected);
            cible.updateDefense(-5);

            this.updateMana(-20);

            cible.getHealth();
            cible.getStrength();

            this.getMana();

            System.out.println("The target has " +cible.getHealth() + " Point of life, " + cible.getDefense() + " of defense and the mage have " + this.getMana() +" mana left.");

            if(cible.getHealth()<=0){
                cible.setVivant(false);
                System.out.println("\nThe target is dead! Another small effort.");
            }

        }
    }

    @Override
    public void attack(Combatant cible) {

        System.out.println("You choose to attack !");
        System.out.println("FireBall = (1)");
        System.out.println("IceBall = (2)");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        switch(num){
            case 1:
                this.FireBall(cible);
                break;

            case 2:
                this.IceBall(cible);
                break;
        }




    }


    @Override
    public void levelUp() {
        this.maxHealth+=10;
        this.mana = this.maxMana;
        this.health = this.maxHealth;
        this.updatePower(15);
    }


}
