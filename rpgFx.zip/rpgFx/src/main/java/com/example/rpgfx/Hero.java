package com.example.rpgfx;

import java.util.ArrayList;


public abstract class Hero extends Combatant {
    protected int power;
    protected HeroType heroType;
    protected Team team;

    protected ArrayList<Consumable> consumables = new ArrayList<Consumable>();



    public HeroType getHeroType() {return this.heroType;}
    public ArrayList<Consumable> getConsumables() {
        return consumables;
    }


    protected int maxMana = 100;
    protected int maxHealth = 100;


    public void addConsumable(Consumable consumable){
        this.getConsumables().add(consumable);
    }

    public void useConsumable(Consumable c){
        c.use(this);
        this.consumables.remove(c);
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public int getMaxMana() {
        return maxMana;
    }


}
