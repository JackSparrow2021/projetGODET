package com.example.rpgfx;

import java.util.Scanner;

public class Warrior extends Hero {


    public Warrior(String name, int health, int strength, int defense, Team team) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.defense = defense;
        this.heroType = HeroType.WARRIOR;
        this.team = team;
        this.team.addCombatant(this);
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Food("Sweat", 30));
        this.consumables.add(new Food("Sweat", 30));
        this.maxHealth = 100;

    }

    public void tackle(Combatant cible){
        int DamageInflected = this.getStrength() - cible.getDefense();
        if(this.getHealth()<=20){
            System.out.println("it was an honor to fight alongside you...");

        }else{
            System.out.println("The shock will hurt !");
        }

        cible.updateHealth(-DamageInflected);
        cible.getHealth();
        this.updateHealth(-20);
        this.updateStrength(+10);

        System.out.println("The target now has " + cible.getHealth() + " Point of life and your strength has become " + this.getStrength() + " but you health has decrease and become " + this.getHealth() );
        if(cible.getHealth()<=0){
            cible.setVivant(false);
            System.out.println("la cible est morte ! encore un petit effort.");
        }
    }

    public void headscarf(Combatant cible){
        int DamageInflected = this.getStrength() - cible.getDefense();
        System.out.println("The helmet hurts more than you think !");

        cible.updateHealth(-DamageInflected);
        cible.getHealth();

        System.out.println("The target now has " + cible.getHealth() + " Point of life");

        if(cible.getHealth()<=0){
            cible.setVivant(false);
            System.out.println("\nThe target is dead! Another small effort.");

        }


    }

    @Override
    public void attack(Combatant cible) {


        System.out.println("You choose to attack !");
        System.out.println("Tackle = (1)");
        System.out.println("Headscarf = (2)");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        switch (num) {
            case 1:
                this.tackle(cible);
                break;


            case 2:
                this.headscarf(cible);
                break;

        }

    }


    @Override
    public void levelUp() {
        this.maxHealth+=10;
        this.health = this.maxHealth;
        this.updateStrength(10);

    }
}
