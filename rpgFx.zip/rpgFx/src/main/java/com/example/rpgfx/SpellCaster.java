package com.example.rpgfx;

public abstract class SpellCaster extends Hero {



}