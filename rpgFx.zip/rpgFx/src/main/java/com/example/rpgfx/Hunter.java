package com.example.rpgfx;
import java.util.Random;
import java.util.Scanner;

public class Hunter extends Hero {


    private int arrow = 10;


    public Hunter(String name, int health, int mana, int strength, int defense, int arrow, Team team) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.arrow = arrow;
        this.power = power;
        this.mana = mana;
        this.defense = defense;
        this.heroType = HeroType.HUNTER;
        this.consumables.add(new Potion("Tonic",20));
        this.consumables.add(new Food("Sweat", 30));
        this.team = team;
        this.team.addCombatant(this);

    }

    public void updateArrow(int x) {
        this.arrow += x;
    }

    public int getArrow() {
        return this.arrow;
    }


    public void superArrow(Combatant cible) {
        if (this.getArrow() == 0) {
            System.out.println("Pity ! you don't have any arrow.");
        } else {
            Random random = new Random();
            int R = random.nextInt(11);
            int DamageInflected = this.getStrength() - cible.getDefense();
            if (R > 5) {
                System.out.println("Right on target ! Critical Strike !");
                DamageInflected *= 2;


            }
            cible.updateHealth(-DamageInflected);
            this.updateArrow(-1);
        }

        cible.getHealth();

        this.getArrow();
        System.out.println("The target now has " + cible.getHealth() + " Point of Life but you only have " + getArrow() + " arrow left...");
        if(cible.getHealth()<=0){
            cible.setVivant(false);

            System.out.println("The target is dead! Another small effort.");
        }
    }

    public void lifeSteal(Combatant cible) {
        if (this.getMana() < 25) {
            System.out.println("Pity ! you don t have any mana.");
        } else {
            if (this.getArrow() == 0) {
                System.out.println("Pity ! you don't have any arrow.");
            } else {
                Random random = new Random();
                int R = random.nextInt(11);
                int DamageInflected = this.getStrength() - cible.getDefense();
                if (R > 8) {
                    System.out.println("Critical Strike !");
                    DamageInflected *= 2;
                }
                cible.updateHealth(-DamageInflected);
                this.updateArrow(-1);
                this.updateMana(-25);
                this.updateHealth(25);
            }

            cible.getHealth();
            if(this.getHealth()>this.getMaxHealth()){
                this.setHealth(this.maxHealth);
            }
            this.getHealth();
            this.getArrow();
            this.getMana();
            System.out.println("Right on target ! The target now has " + cible.getHealth() + " Point of Life and you have " + this.getHealth()+ " Point of life, but you only have " + getArrow() + " arrow left and " + this.getMana() + " of mana...");
            if(cible.getHealth()<=0){
                cible.setVivant(false);
                System.out.println("\nThe target is dead! Another small effort.");
            }
        }
    }
        @Override
        public void attack (Combatant cible){

            System.out.println("You choose to attack !");
            System.out.println("SuperArrow = (1)");
            System.out.println("LifeSteal = (2)");
            Scanner sc = new Scanner(System.in);
            int num = sc.nextInt();
            switch (num) {
                case 1:
                    this.superArrow(cible);
                    break;

                case 2:
                    this.lifeSteal(cible);
                    break;
            }
        }

    @Override
    public void levelUp() {
        this.maxHealth+=10;
        this.mana = this.maxMana;
        this.health = this.maxHealth;
        this.updateArrow(5);
        this.updateStrength(10);
    }
}


